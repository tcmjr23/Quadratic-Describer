import java.util.Scanner;

//Troy Mosqueda
//9/23/22
//Methods required to analyze a quadratic function
public class Quadratic {
public static String quadrDescriber (double a, double b, double c) {
		
		String answer = "y = " + a + "^2 + " + b + " x + " + c;
		String newLine = "\n";
		String conc = "\n"; 
		if (a >= 0) {
			conc = "\nOpens: Up";
		}
		else {
			conc = "\nOpens: Down";
		}
		
		
		double symmetry = round2(-b/2*a);
		String Symmetry = "\nAxis of Symmetry: " + symmetry;
		double vertex = a*round2(-b/2*a)*round2(-b/2*a) + b*round2(-b/2*a)+c;
		String xInt = "\nx-intercept(s): " + (quadForm((int) a,(int) b,(int) c)); 
		double yInt = c;
		return answer + newLine + conc + Symmetry + newLine + "Vertex: (" + symmetry + ", " + vertex + ")" + xInt + newLine + "y-intercept: " + yInt; 
	}
	
	
	public static String quadForm(int a, int b, int c) {
		double discriminant = discriminant(a,b,c);
		if(discriminant<0) {
			return "no real roots";
		} else if(discriminant == 0) {
			double oneRoot = ((-1*b)/(2*a));
			return oneRoot+"";
		}else {
			double plus = round2((-1*b + sqrt(discriminant))/(2*a));
			double minus = round2((-1*b - sqrt(discriminant))/(2*a));
			double max = max(plus,minus);
			double min = min(minus,plus);
			return absValue(max) + " and " + -max;
		
			}
		}

	public static double max(double num1, double num2) {
		if (num1>num2) {
			return num1;
		}else {
		return num2;
		}
	}
//returns the minimum value between two ints
	public static double min(double plus, double minus) {
		if (plus<minus) {
			return plus;
		}else {
			return minus;
		}
	}
//returns a double rounded to the hundredths place
	/*public static double round2(double rnd) { 
		String numOfDecimals = Double.toString(rnd%1);
		if (rnd<0) {
			rnd = (rnd*(10*(10*(numOfDecimals.length()-1)))-5);
			return (rnd - rnd%10)/1000;
		}else {
			rnd = (rnd*1000+5);
			return(rnd-rnd%10)/1000;
		}
	}*/
	public static double round2(double num) {
		if (num<0) {
			num = num - num - num;
			num = num*1000+5;
			num = (num-num%10)/1000;
			return num-num-num;
			}else {
				num = num*1000+5;
				return (num-num%10)/1000;
			}
	}
	//will calculate the discriminant within quadratic formula
	public static double discriminant(double a, double b, double c) {
		return (b*b-4*(a*c));
	}
	//returns the square root of a double
	public static double sqrt(double n) {
		double a = n;
		for(int i=1; i<=n; i++) {
			a = (0.5*(n/a+a));}
			a = round2(a);
			return a;
	}
	public static double absValue(double abs) {
		if(abs<0) {
			return abs*-1;
	}else {
		return abs;
		}
	}
}//quadForm()
	//discriminant()
	//round2()
	//absValue()
	//square()
	//sqrt()
	//max()
	//min()

