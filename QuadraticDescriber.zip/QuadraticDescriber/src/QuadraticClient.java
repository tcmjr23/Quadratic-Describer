import java.util.*;

//Troy Mosqueda
//9/23/22
//Client code for calculate part 5
public class QuadraticClient {
	public static void main(String[] args) {
		//Greeting
		//Loop (while)
			//get input from user
			//call quadrDescriber() to analyze the
			//print the results
			//ask --go again?
			//get answer
		Scanner userImput = new Scanner(System.in);
		boolean prog = true;
		do{
			System.out.println("Welcome to the Quadratic Describer");
			System.out.println("Provide values for the coefficients a, b, and c");
			System.out.println("");
			System.out.print("a: ");
			double a = userImput.nextInt();
			System.out.print("b: ");
			double b = userImput.nextInt();
			System.out.print("c: ");
			double c = userImput.nextInt();
			System.out.println("");
			System.out.println("Description of the graph of:");
			System.out.println(Quadratic.quadrDescriber(a,b,c));
			System.out.println();
		
			System.out.println("do you want to keep going? (Type \"quit\" to end)");
			System.out.print("Response: ");
			String response = userImput.next();
			if (response.equals("quit")) {
				prog = false;
				}
			}while(prog == true);
		userImput.close();
	}
}

		
	
